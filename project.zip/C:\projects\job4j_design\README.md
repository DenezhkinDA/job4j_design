Учебный репозиторий job4j Java Junior:
2.1.0 - Maven

2.1.1 - Iterator

2.1.2 - Generic

2.1.3 - List

2.1.4 - Set

2.1.5 - Map

2.1.6 - Tree

2.1.7 - Test questions

2.2.1 - IO

2.2.2 - Socket

2.2.3 - Log

2.2.4 - Serializable

2.2.5 - Test questions

2.3.0 - PostgreSQL

2.3.1 - Create Update Insert

2.3.2 - Query

2.3.3 - Outer Join

2.3.4 - JDBC

2.3.5 - Project Java vacancy

2.3.6 - Test questions

2.4.1 - garbish collector

2.4.2 - type garbish collector

2.4.3 - profile

2.4.4 - type soft weak ref

2.4.5 - Test questions

2.5.0 - TDD

2.5.1 - SRP

2.5.2 - OCP

2.5.3 - LSP

2.5.4 - ISP

2.5.5 - DIP

2.5.6 - Test questions
